//
//  CardboardSoftApp.swift
//  CardboardSoft
//
//  Created by Nuggz on 27/02/24.
//

import SwiftUI

@main
struct CardboardSoftApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
