//
//  PageModel.swift
//  SlidingIntro
//
//  Created by Rod Espiritu Berra on 05/03/24.
//

import Foundation

struct Page : Identifiable, Equatable {
    let id = UUID()
    var name: String
    var description: String
    var imageUrl: String
    var tag: Int //Ubicación de la página creada
    
    
    static var samplePage = Page(name: "¡Bienvenido al cambio!", description: "", imageUrl: "reciclar", tag: 0)
    
    static var samplePages : [Page] = [
        Page(name: "Transforma tu mundo, transforma el planeta", description: "Explora la innovadora tecnología de clasificación mediante machine learning que te ayuda a identificar rápidamente el tipo de basura que estás reciclando. ", imageUrl: "reciclar", tag: 0),
        
        Page(name: "Descubre y clasifica", description: "Sumérgete en nuestra base de datos ecológica para obtener información valiosa sobre prácticas sostenibles y cómo tu participación contribuye al bienestar del medio ambiente. ", imageUrl: "reutilizar", tag: 1),
        
        Page(name: "Conéctate con el planeta", description: "Aprende a través de consejos prácticos y estadísticas impactantes cómo pequeñas acciones diarias pueden tener un gran impacto en la preservación del planeta.", imageUrl: "tierra", tag: 2)
    ]
}
