//
//  ContentView.swift
//  Waste Manager
//
//  Created by Ultiimate Dog on 28/02/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationBarView()
    }
}

#Preview {
    ContentView()
}
